<?php

use Illuminate\Support\Facades\Route;
use Pterodactyl\Http\Controllers\Base;
use Pterodactyl\Http\Middleware\RequireTwoFactorAuthentication;

Route::get('/', [Base\IndexController::class, 'index'])->name('index')->fallback();
Route::get('/account', [Base\IndexController::class, 'index'])
    ->withoutMiddleware(RequireTwoFactorAuthentication::class)
    ->name('account');

Route::get('/locales/locale.json', Base\LocaleController::class)
    ->withoutMiddleware(['auth', RequireTwoFactorAuthentication::class])
    ->where('namespace', '.*');

Route::get('/api/public/status', function () {
    $settingsPath = base_path('resources/settings/status_nodes.json');
    $whitelistedNodes = file_exists($settingsPath) ? (json_decode(file_get_contents($settingsPath), true) ?? []) : [];

    if (empty($whitelistedNodes)) {
        return [];
    }

    $nodes = \Pterodactyl\Models\Node::query()
        ->with('location')
        ->withCount('servers')
        ->whereIn('id', $whitelistedNodes)
        ->get();

    return $nodes->map(function (\Pterodactyl\Models\Node $node) {
        $cacheKey = 'public_status_node_' . $node->id;
        
        $data = \Illuminate\Support\Facades\Cache::remember($cacheKey, 60, function () use ($node) {
            $result = [
                'status' => 'up',
                'load' => null,
                'container_count' => null,
            ];

            if ($node->maintenance_mode) {
                $result['status'] = 'maintenance';
                return $result;
            }

            try {
                $response = \Illuminate\Support\Facades\Http::withHeaders([
                    'Authorization' => 'Bearer ' . $node->getDecryptedKey(),
                    'Accept' => 'application/json',
                ])->timeout(2)->get($node->getConnectionAddress() . '/api/system');

                if ($response->successful()) {
                    $json = $response->json();
                    $result['status'] = 'up';
                    $result['cpu_cores'] = $json['cpu_count'] ?? 0;
                    $result['wings_version'] = $json['version'] ?? 'Unknown';
                    $result['load'] = $json['load'] ?? $json['system_load'] ?? null;
                } else {
                    $result['status'] = 'down';
                }
            } catch (\Exception $e) {
                $result['status'] = 'down';
            }

            // Always calculate allocation stats from DB for maximum accuracy
            try {
                $assigned = \DB::table('servers')
                    ->where('node_id', $node->id)
                    ->selectRaw('SUM(memory) as total_mem, SUM(disk) as total_disk')
                    ->first();
                
                $result['mem_percent'] = $node->memory > 0 ? round(($assigned->total_mem / $node->memory) * 100) : 0;
                $result['disk_percent'] = $node->disk > 0 ? round(($assigned->total_disk / $node->disk) * 100) : 0;
            } catch (\Exception $e) {
                $result['mem_percent'] = 0;
                $result['disk_percent'] = 0;
            }

            return $result;
        });

        return [
            'id' => $node->id,
            'name' => $node->name,
            'location' => $node->location->short,
            'status' => $node->maintenance_mode ? 'maintenance' : ($data['status'] ?? 'down'),
            'memory' => $node->memory,
            'disk' => $node->disk,
            'servers_count' => $node->servers_count,
            'cpu_cores' => $data['cpu_cores'] ?? 0,
            'wings_version' => $data['wings_version'] ?? 'Unknown',
            'mem_percent' => $data['mem_percent'] ?? 0,
            'disk_percent' => $data['disk_percent'] ?? 0,
            'load' => $data['load'] ?? null,
        ];
    });
})->withoutMiddleware(['auth', \Pterodactyl\Http\Middleware\RequireTwoFactorAuthentication::class]);

Route::get('/api/public/announcements', function () {
    $path = base_path('resources/settings/announcements.json');
    if (!file_exists($path)) {
        return response()->json([]);
    }
    return response()->file($path, ['Content-Type' => 'application/json']);
})->withoutMiddleware(['auth', \Pterodactyl\Http\Middleware\RequireTwoFactorAuthentication::class]);

Route::get('/{react}', [Base\IndexController::class, 'index'])
    ->where('react', '^(?!(\/)?(api|auth|admin|daemon)).+');
