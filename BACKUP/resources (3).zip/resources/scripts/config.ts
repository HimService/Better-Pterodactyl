/**
 * Better Pterodactyl - Frontend Configuration
 * 
 * You can customize various aspects of the frontend interface here.
 */
const config = {
    /**
     * The language used for the login page and other authentication views
     * before a user is logged in.
     * 
     * Options: 'zh', 'en', 'ja'
     */
    login_language: 'en',

    /**
     * Fallback language if the primary language detection fails.
     */
    fallback_language: 'en',

    /**
     * Theme Customization
     */
    theme: {
        /**
         * The primary accent color for the theme.
         * Default: #8b5cf6 (Indigo 500)
         */
        primary_color: '#8b5cf6',
    },
};

export default config;
