import React from 'react';
import styled from 'styled-components/macro';
import { theme } from 'twin.macro';

const StatusIndicatorBox = styled.div<{ color: 'red' | 'yellow' | 'green' | 'neutral' }>`
    width: 10px;
    height: 10px;
    border-radius: 50%;

    ${({ color }) => {
        switch (color) {
            case 'red':
                return `background-color: ${theme('colors.red.500')};`;
            case 'yellow':
                return `background-color: ${theme('colors.yellow.500')};`;
            case 'green':
                return `background-color: ${theme('colors.green.500')};`;
            default:
                return `background-color: ${theme('colors.gray.500')};`;
        }
    }}
`;

export const StatusIndicator = ({ color }: { color: 'red' | 'yellow' | 'green' | 'neutral' }) => {
    return <StatusIndicatorBox color={color} />;
};