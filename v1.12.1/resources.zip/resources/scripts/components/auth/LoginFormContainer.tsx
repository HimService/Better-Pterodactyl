import React, { forwardRef } from 'react';
import { Form } from 'formik';
import styled from 'styled-components/macro';
import { breakpoint } from '@/theme';
import FlashMessageRender from '@/components/FlashMessageRender';
import tw from 'twin.macro';

type Props = React.DetailedHTMLProps<React.FormHTMLAttributes<HTMLFormElement>, HTMLFormElement> & {
    title?: string;
};

const Container = styled.div`
    ${breakpoint('sm')`
        ${tw`w-full`}
    `};

    ${breakpoint('xl')`
        ${tw`w-full`}
    `};
`;

export default forwardRef<HTMLFormElement, Props>(({ title, ...props }, ref) => (
    <Container>
        {title && (
            <div className="mb-8">
                <h2 className="text-3xl md:text-4xl font-black tracking-tight text-neutral-900 dark:text-white mb-2">
                    {title}
                </h2>
                <p className="text-neutral-500 dark:text-neutral-400 text-sm font-medium">
                    Please enter your credentials to access the panel.
                </p>
            </div>
        )}

        <FlashMessageRender css={tw`mb-6 px-1`} />

        <Form {...props} ref={ref}>
            <div className="w-full transition-all duration-500 relative">
                <div className="flex-1 relative z-10">{props.children}</div>
            </div>
        </Form>

        <p className="text-center text-xs mt-12 transition-colors text-neutral-400 dark:text-neutral-500 font-medium">
            &copy; 2015 - {new Date().getFullYear()}&nbsp;
            <a
                rel={'noopener nofollow noreferrer'}
                href={'https://pterodactyl.io'}
                target={'_blank'}
                className="no-underline transition-colors hover:text-brand-500 dark:hover:text-brand-400"
            >
                Pterodactyl Software
            </a>
        </p>
    </Container>
));
